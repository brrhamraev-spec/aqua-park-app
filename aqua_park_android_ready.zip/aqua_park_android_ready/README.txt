AQUA PARK — ANDROIDGA TAYYOR LOYIHA

Bu paket hozirgi Aqua Park web-ilovamizni Android APKga aylantirish uchun tayyorlangan.

Tarkibi:
- www/index.html — ilovaning ishlaydigan birinchi versiyasi
- capacitor.config.json — Android paket nomi va sozlamalar

APK yaratish uchun kompyuterda:
1. Node.js va Android Studio o‘rnatiladi.
2. Shu papkada terminal ochiladi.
3. Capacitor o‘rnatiladi va Android loyiha yaratiladi.
4. www papkasi Android ilovasiga qo‘shiladi.
5. Android Studio orqali APK build qilinadi.

Eslatma:
Hozirgi versiyada ma’lumotlar qurilmaning o‘zida saqlanadi. Bir nechta telefon o‘rtasida umumiy ma’lumot kerak bo‘lsa, keyingi versiyada bulutli ma’lumotlar bazasi qo‘shish kerak.
